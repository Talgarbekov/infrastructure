# Ansible Collection - talgarbekov.infrastructure
> created talgarbekov.infrastructure collection (different versions)
versions 1-4 i just built collection
version 6 - contains roles
version 7 - contains r1softagent
roles:
    1. ec2
    2. wordpress (on ubuntu services)
    3. group
    4. iam user
    5. r1soft

